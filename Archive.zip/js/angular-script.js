	// create the module and name it scotchApp
	var scotchApp = angular.module('scotchApp', ['ngRoute']);

	// configure our routes
	scotchApp.config(function($routeProvider) {
		$routeProvider

			.when('/', {
				templateUrl : 'pages/business.html',
				controller  : 'mainController'
			})

			.when('/business', {
				templateUrl : 'pages/business.html',
				controller  : 'mainController'
			})

			// route for the about page
			.when('/team', {
				templateUrl : 'pages/team.html',
				controller  : 'teamController'
			})

			// route for the contact page
			.when('/portfolio', {
				templateUrl : 'pages/portfolios.html',
				controller  : 'portfoliosController'
			})

			.when('/investor', {
				templateUrl : 'pages/investor.html',
				controller  : 'investorController'
			})

			.when('/contact', {
				templateUrl : 'pages/contact.html',
				controller  : 'contactController'
			});
			
	});

	scotchApp.run(function($rootScope, $location, $anchorScroll, $routeParams) {
  	$rootScope.$on('$routeChangeSuccess', function(newRoute, oldRoute) {
    $location.hash($routeParams.scrollTo);
    $anchorScroll();  
  	});
	})

	

	// create the controller and inject Angular's $scope
	scotchApp.controller('mainController', function($scope, $location, $anchorScroll, $routeParams) {
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
	});

	scotchApp.controller('aboutController', function($scope) {
		$scope.message = 'Look! I am an about page.';
	});

	scotchApp.controller('contactController', function($scope) {
		$scope.message = 'Contact us! JK. This is just a demo.';
	});