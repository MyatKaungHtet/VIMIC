	// create the module and name it scotchApp
	var scotchApp = angular.module('scotchApp', ['ngRoute']);

	// configure our routes
	scotchApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'pages/business.html',
				controller  : 'mainController'
			})

			.when('/business', {
				templateUrl : 'pages/business.html',
				controller  : 'mainController'
			})

			// route for the about page
			.when('/team', {
				templateUrl : 'pages/team.html',
				controller  : 'teamController'
			})

			// route for the contact page
			.when('/portfolios', {
				templateUrl : 'pages/portfolios.html',
				controller  : 'portfoliosController'
			})

			.when('/investor', {
				templateUrl : 'pages/investor.html',
				controller  : 'investorController'
			})

			.when('/contact', {
				templateUrl : 'pages/contact.html',
				controller  : 'contactController'
			});
			
	});

	// create the controller and inject Angular's $scope
	scotchApp.controller('mainController', function($scope) {
		// create a message to display in our view
		
	});

	scotchApp.controller('teamController', function($scope) {
		
	});

	scotchApp.controller('contactController', function($scope) {
		
	});

	scotchApp.controller('investorController', function($scope) {
		
	});

	scotchApp.controller('portfoliosController', function($scope) {
		
	});
